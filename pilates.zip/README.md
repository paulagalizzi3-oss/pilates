# CorePilates - Sistema de Control Horario y Recuperación de Clases 🧘‍♀️📅

Este es un sistema desarrollado en Python para gestionar las agendas semanales de un estudio de Pilates. Admite la gestión de asistencia, liberación de lugares (avisos de inasistencia) y reserva de clases de recuperación.

---

## 🌟 Reglas de Negocio Implementadas

1. **Capacidad Máxima:** Cada turno (hora de clase) tiene un límite estricto de **10 alumnos**.
2. **Días de Operación:** Lunes a Viernes.
3. **Liberación de Lugares (Cancelar Asistencia):**
   - Si un alumno avisa que faltará a una clase en una fecha específica, su cupo se libera temporalmente para esa fecha.
   - Al liberar el lugar, el alumno gana automáticamente **1 Crédito de Recuperación** para usar en el mismo mes.
4. **Reserva de Recuperaciones:**
   - Un alumno puede gastar sus créditos mensuales reservados para agendar una clase de recuperación en cualquier turno que tenga cupo disponible (< 10 alumnos inscritos) en la misma semana/mes.
5. **Vencimiento de Créditos:**
   - Los créditos expiran al finalizar el mes en curso en el que se generó la falta. Se calculan dinámicamente aislando el balance mensual para evitar inconsistencias.
6. **Perfiles de Usuario:**
   - **Administrador:** Administra la lista de alumnos, crea asignaciones de horarios fijos recurrentes y puede forzar inasistencias o agendar recuperaciones de forma manual para cualquier alumno.
   - **Alumno:** Puede auto-gestionarse seleccionando su nombre. Visualiza su agenda con sus horarios fijos resaltados, puede liberar sus clases fijos y agendar sus propias recuperaciones utilizando sus créditos del mes.

---

## 🚀 Guía de Instalación y Ejecución

1. **Abrir el espacio de trabajo:**
   Ubícate en la carpeta raíz del proyecto (donde está este README).

2. **Crear e iniciar el entorno virtual de Python:**
   ```powershell
   python -m venv venv
   # Activar en Windows
   .\venv\Scripts\activate
   ```

3. **Instalar dependencias:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Inicializar y poblar la Base de Datos:**
   Crea la base de datos local SQLite (`pilates.db`) y carga datos iniciales de prueba (18 alumnos, horarios fijos semanales y faltas simuladas para probar créditos):
   ```bash
   python init_db.py
   ```

5. **Correr las pruebas automatizadas de lógica de negocio:**
   Ejecuta los tests unitarios para validar las reglas de negocio (cupos, créditos y cancelaciones):
   ```bash
   python test_pilates.py
   ```

6. **Iniciar el servidor local FastAPI:**
   ```bash
   python -m uvicorn app.main:app --reload
   ```

7. **Ver el Dashboard en tu navegador:**
   - Entra en: **[http://localhost:8000](http://localhost:8000)**.
   - Prueba alternando entre **Modo Administrador** y **Modo Alumno** (seleccionando un alumno en la lista desplegable) para ver la diferencia de acciones en la agenda interactiva.

---

## 🌐 Publicar en Render

La app está lista para Render (archivo `render.yaml`).

1. Creá una base PostgreSQL (por ejemplo, gratis en [neon.tech](https://neon.tech)) y copiá su dirección de conexión.
2. En [render.com](https://render.com): **New › Blueprint** y elegí este repositorio.
3. Completá las variables que pide:
   - `DATABASE_URL`: la dirección de la base.
   - `ADMIN_USERNAME` y `ADMIN_PASSWORD`: el usuario y la contraseña del primer administrador.
4. Al terminar, Render te da la dirección de la app (por ejemplo `https://control-de-turnos.onrender.com`).

La primera vez que arranca, la app crea las tablas y el administrador. Los datos de prueba de `init_db.py` **nunca** se cargan en la base real.

## 📲 Instalar como app

En Android y computadora, el navegador ofrece **Instalar**. En iPhone: Safari › Compartir › **Agregar a inicio**.

---

## 📁 Estructura de Archivos

- `app/config.py`: Parámetros globales y cadena de conexión a la base de datos.
- `app/database.py`: Motor de SQLAlchemy y generador de sesiones de base de datos.
- `app/models.py`: Modelos SQLAlchemy para la base de datos relacional.
- `app/schemas.py`: Esquemas de validación Pydantic para APIs.
- `app/crud.py`: Lógica principal del sistema (cálculo de créditos del mes, cupos libres y reservas).
- `app/main.py`: Endpoints REST del backend y provisión del frontend estático.
- `web/`: Archivos HTML, CSS y JavaScript del Dashboard.
- `init_db.py`: Script para cargar datos simulados (solo en la base local).
- `render.yaml`: Configuración para publicar en Render.
- `web/manifest.webmanifest` y `web/sw.js`: Instalación como app.
- `test_pilates.py`: Conjunto de pruebas unitarias.
